# ES Marketing Manager — V2

This version connects the web app to your Supabase authentication and database.

## Local setup
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. In Supabase go to Project Settings -> API and copy the Project URL and anon/publishable key into `.env.local`.
5. Run `npm run dev`.
6. Open `http://localhost:3000/login`.

## Important
The app does NOT contain real Facebook/Instagram/WhatsApp credentials. Those connections must be authorized by the business through the appropriate official APIs after deployment.

Your Supabase database should already contain the tables and owner profile created in the previous setup steps.
