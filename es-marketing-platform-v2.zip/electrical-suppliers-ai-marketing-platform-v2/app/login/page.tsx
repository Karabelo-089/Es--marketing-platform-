"use client";
import {useState} from "react";
import {createClient} from "@/lib/supabase-browser";
import {useRouter} from "next/navigation";

export default function Login(){
 const router=useRouter(); const supabase=createClient();
 const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState(""); const [busy,setBusy]=useState(false);
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError("");
   const {error}=await supabase.auth.signInWithPassword({email,password});
   if(error){setError(error.message);setBusy(false);return}
   router.push("/dashboard"); router.refresh();
 }
 return <main className="login"><div className="login-card"><div className="logo">ES</div><p className="eyebrow">YOUR MARKETING PLATFORM</p><h1>Welcome back</h1><p className="muted">Sign in to manage your clients and branches.</p>
 <form onSubmit={submit}><label>Email<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input type="password" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="Your password"/></label>{error&&<div className="error">{error}</div>}<button className="primary full" disabled={busy}>{busy?"Signing in…":"Sign in"}</button></form></div></main>
}