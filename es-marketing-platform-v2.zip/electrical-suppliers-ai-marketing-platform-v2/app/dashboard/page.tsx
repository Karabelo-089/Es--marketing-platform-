import {redirect} from "next/navigation";
import {createClient} from "@/lib/supabase-server";
import DashboardClient from "./ui";

export default async function Dashboard(){
 const supabase=createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user) redirect("/login");
 const {data:profile}=await supabase.from("profiles").select("full_name,role,organization_id").eq("id",user.id).single();
 if(!profile) return <main className="login"><div className="login-card"><h1>Account not linked</h1><p className="muted">Your Supabase user exists, but it is not linked to a platform workspace yet.</p></div></main>;
 const {data:org}=await supabase.from("organizations").select("id,name,tagline").eq("id",profile.organization_id).single();
 const {data:branches}=await supabase.from("branches").select("id,name,city").eq("organization_id",profile.organization_id).order("name");
 return <DashboardClient userEmail={user.email||""} profile={profile} org={org} branches={branches||[]}/>;
}